
sentence = input("User input sequence of words: ")
words = sentence.split()
words.sort()
print(words)