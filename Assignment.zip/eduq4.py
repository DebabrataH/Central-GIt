sentence = input("User input words: ")
chars = list(sentence)
letters = 0
digits = 0

for c in chars:
    if c.isalpha():
        letters += 1
    elif c.isdigit():
        digits += 1

print("LETTERS:{}".format(letters))
print("DIGITS:{}".format(digits))
