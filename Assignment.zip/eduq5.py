input_num = input("User input number: ")
reverse = input_num[::-1]
if input_num == reverse:
    print('It is a palindrome')
else:
    print('It is mot a palindrome')


