
num=int(input("Enter a no: "))

for n in range(num):
    counter = n+1
    if(num % counter == 0):
        # counter is a factor of num
        if counter % 2 == 0:
            # factor is a even number
            print('{:20} {:-3}'.format('Even factor',counter))
        else:
            # factor is a odd number
            print('{:20} {:-3}'.format('Odd factor',counter))